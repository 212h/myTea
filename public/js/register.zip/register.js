// +++++++++++++++++改写jquery++++++↓+++++++++++++
// // // 查找触发事件的元素

var $txtUname = $("#uname");
var $txtUpwd = $("#upwd");
var $txtCpwd = $("#cpwd");
var $txtEmail = $("#email");
var $txtPhone = $("#phone");
console.log($txtUname,$txtUpwd,$txtCpwd,$txtPhone);
//绑定事件
/*功能1：当表单元素获取焦点时给他穿件衣服，给人的印象我正在输入文本框*/
//用户名框获取焦点
$txtUname.focus(function(){
    //查找要修改的元素
    var $txt = $(this);
    console.log($txt);
    var $span = $txt.parent().next().children();
    console.log("$span"+$span);
    $txt.addClass(" txt_focus ");
    $span.removeClass("vali_info");//清空他的class,让他显示
});
//密码框获取焦点
$txtUpwd.focus(function(){
    //查找要修改的元素
    var $txt = $(this);
    console.log($txt);
    var $span = $txt.parent().next().children();
    console.log("$span"+$span);
    $txt.addClass(" txt_focus");
    $span.removeClass("txt_focus");//清空他的class,让他显示
});
// 重复密码框获取焦点
$txtCpwd.focus(function(){
    //查找要修改的元素
    var $txt = $(this);
    console.log($txt);
    var $span = $txt.parent().next().children();
    console.log("$span"+$span);
    $txt.addClass(" txt_focus");
    $span.removeClass("vali_info");//清空他的class,让他显示
});
//邮箱框获取焦点
$txtEmail.focus(function(){
    //查找要修改的元素
    var $txt = $(this);
    console.log($txt);
    var $span = $txt.parent().next().children();
    console.log("$span"+$span);
    $txt.addClass(" txt_focus ");
    $span.removeClass("vali_info");//清空他的class,让他显示
});
//电话框获取焦点
$txtPhone.focus(function(){
    //查找要修改的元素
    var $txt = $(this);
    console.log($txt);
    var $span = $txt.parent().next().children();
    console.log("$span"+$span);
    $txt.addClass("txt_focus");
    $span.removeClass("vali_info");//清空他的class,让他显示
});

// /*功能2：失去焦点进行验证用户输入的格式是否正确*/
$txtUname.blur(function(){//失去焦点时，自动调用vali()函数
    vali($(this),/^[a-zA-Z0-9_\u4e00-\u9fa5]{1,10}$/);
});
$txtUpwd.blur(function(){//失去焦点时，自动调用vali()函数
    vali($(this),/^[0-9]{6,12}$/);
});
$txtCpwd.blur(function(){//失去焦点时，自动调用cpwd()函数
    cpwd();
});
$txtEmail.blur(function(){
    vali($(this),/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/);
});
$txtPhone.blur(function(){
    vali($(this),/^(\+86|0086)?\s*1[3-8]\d{9}$/);
});
function vali($txt,reg){
    $txt.removeClass("txt_focus");
    //查找要修改的元素
    var $span = $txt.parent().next().children();    
    if(reg.test($txt.val())){
        $span.addClass(" vali_success");
        return true;
    }else{
        $span.addClass("vali_fail");
        return false;
    }
}
//重复密码失去焦点时，是否和upwd一样单独验证
function cpwd(){
    var reg = /^[0-9]{6,12}$/;
    //查找要修改的元素
    var $span = $("#cpwd").parent().next().children();
    console.log($span);
    $txtCpwd.removeClass("txt_focus");
    if(reg.test($txtCpwd.val()) && $txtCpwd.val() == $txtUpwd.val()){
        $span.addClass(" vali_success ");
        return true;
    }else{
        $span.addClass( "vali_fail" ) ;
        $span.innerHTML = "两次密码不一致，请重新输入!";
        return false;
    }
}

// +++++++++++++++++改写jquery++++++↑+++++++++++++
/*功能3:一旦出错把光标定位到出错的元素上去:一个一个验证，第一个没有通过,第一个定住不要走了,第二个没通过,第二天定住不要走了,只有当全部通过了,才能提交——非常人性化，可以帮你找错*/
 console.log(10111);

    // if(!vali($txtUname,/^[a-zA-Z0-9_\u4e00-\u9fa5]{1,10}$/)){//如果用户名没通过,让他获取焦点
    //      console.log(101);
    //     $txtUname.focus();
        
    // }else if(!vali($txtUpwd,/^[0-9]{6,12}$/)){//否则如果密码框验证没通过,让密码框获取焦点
    //     $txtUpwd.focus();
    //      console.log('102');
    // }else if(!vali($txtCpwd,/^[0-9]{6,12}$/)){//否则如果重复密码框验证没通过,让密码框获取焦点
    //     $txtCpwd.focus();
    //      console.log('103');
    // }else if(!vali($txtEmail,/^[a-zA-Z0-9_.-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z0-9]{2,6}$/)){//否则如果邮箱验证没通过,让邮箱框获取焦点
    //     $txtEmail.focus();
    //      console.log('104');
    // }else if(!vali($txtPhone,/^(\+86|0086)?\s*1[3-8]\d{9}$/)){//否则如果电话号码验证没通过,让电话号码框获取焦点
    //     $txtPhone.focus();
    //      console.log('105');
    // }else{
    //     // document.forms[0].submit();
    //    console.log("111");
    //     // ***********       
    // }

 
////////////////////////////////////////////////////////////////////////////
/*********************功能二****jquery做*****************************/
// 根据后端返回的result的长度判断该用户是否已注册

// ---------------------
//在dom内容加载后就提前触发
    //功能：从哪个页面跳回来的，登陆成功之后还能跳回哪个页面去******************* */
    // $("#btn_register").click(function(){
    //     var $uname = $("#uname").val();//获取uname
    //     var $upwd = $("#upwd").val();//获取upwd
    //     var $email = $("#email").val();
    //     var $phone = $("#phone").val();
    //     console.log($uname,$upwd,$email,$phone);
    //     $.ajax({
    //         url:"http://localhost:3000/users/isregister",
    //         type:"post",
    //         data:{ $uname, $upwd,$email,$phone},
    //         dataType:"json",
    //         success:function(data){
    //             console.log(data);
    //             if(data.code == 0){
    //                 alert("此用户名已被注册，请更换新的用户名从新注册！");
    //             }else{
    //                 alert("注册成功")
    //             }
    //         }
    //     });
    // });

