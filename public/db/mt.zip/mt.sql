#设置客户端连接服务器使用uft8
SET NAMES UTF8;
#丢弃数据库mt,如果存在的话
DROP DATABASE IF EXISTS mt;
#创建数据库mt，使用utf8字符集
CREATE DATABASE mt CHARSET=UTF8;
#进入数据库mt
USE mt;

#首页轮播广告
DROP TABLE IF EXISTS `mt_index_carousel`;
CREATE TABLE `mt_index_carousel`(
    `cid` int(11) NOT NULL auto_increment,
    `img` varchar(128) default NULL,
    `title` varchar(64) default NULL,
    `href` varchar(128) default NULL,
    PRIMARY KEY (`cid`)
);
INSERT INTO `mt_index_carousel` VALUES(1,'img/index/banner/bg1.png','轮播广告商品1','product_details.html?lid=1');
INSERT INTO `mt_index_carousel` VALUES(2,'img/index/banner/bg2.png','轮播广告商品2','product_details.html?lid=18');
INSERT INTO `mt_index_carousel` VALUES(3,'img/index/banner/bg3.png','轮播广告商品3','product_details.html?lid=23');

#index中的6种茶叶种类列表
DROP TABLE IF EXISTS `mt_index_product`;
CREATE TABLE `mt_index_product`(
	`pid` INT PRIMARY KEY AUTO_INCREMENT,
	`title` varchar(64) default NULL,
	`pic` varchar(128) default NULL,
	`href` varchar(128) default NULL,
	`seq_recommended` INT default NULL
);
INSERT INTO `mt_index_product` VALUES(1,'碧螺春茶','img/index/1.jpg','product_details.html?lid=1',1);
INSERT INTO `mt_index_product` VALUES(2,'庐山云雾','img/index/2.jpg','product_details.html?lid=2',2);
INSERT INTO `mt_index_product` VALUES(3,'阿萨姆红茶','img/index/3.jpg','product_details.html?lid=3',3);
INSERT INTO `mt_index_product` VALUES(4,'乌龙茶','img/index/4.jpg','product_details.html?lid=4',4);
INSERT INTO `mt_index_product` VALUES(5,'龙井茶','img/index/5.jpg','product_details.html?lid=5',5);
INSERT INTO `mt_index_product` VALUES(6,'西湖龙井茶','img/index/6.jpg','product_details.html?lid=6',6);




-- Table structure for `mt_tea`
DROP TABLE IF EXISTS `mt_tea`;
CREATE TABLE `mt_tea` (
    `lid` INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `family_id` INT(11) DEFAULT NULL, #商品型号
    `title` VARCHAR(128) DEFAULT NULL,
    `price` DECIMAL(10,2) DEFAULT NULL,
    `promise` VARCHAR(64) DEFAULT NULL,
    `spec` VARCHAR(64) DEFAULT NULL, #规格
    `details` VARCHAR(1024) DEFAULT NULL,
    `description` VARCHAR(1024) DEFAULT NULL, #商品详情下面的大图片上方的描述文字
    `image` VARCHAR(128) DEFAULT NULL, #商品详情下面的大图片
    `shelf_time` BIGINT(20) DEFAULT NULL,
    `sold_count` INT(11) DEFAULT NULL,
    `is_onsale` TINYINT(1) DEFAULT NULL
);

-- Records of mt_tea
INSERT INTO `mt_tea` VALUES (1,1,"碧螺春茶",'150.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);
INSERT INTO `mt_tea` VALUES (2,2,"庐山云雾",'1040.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','散茶包装半两装装。','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',154123456789,1610,1);
INSERT INTO `mt_tea` VALUES (3,3,"阿萨姆红茶",'650.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶饼棉质包装是350g装','红茶，英文为Black tea。红茶在加工过程中发生了以茶多酚酶促氧化为中心的化学反应，鲜叶中的化学成分变化较大，茶多酚减少90%以上，产生了茶黄素红茶属全发酵茶，是以适宜的茶树新牙叶为原料，经萎凋、揉捻（切）、发酵、干燥等一系列工艺过程精制而成的茶。萎凋是红茶初制的重要工艺，红茶在初制时称为“乌茶”。红茶因其干茶冲泡后的茶汤和叶底色呈红色而得名。中国红茶品种主要有：日照红茶、[1]  祁红、昭平红、霍红、滇红、越红、泉城红、泉城绿、苏红、川红、英红、东江楚云仙红茶等，尤以祁门红茶最为著名，2013年湖南东江楚云仙红茶喜获“中茶杯”特等奖。','茶红素等新成分。香气物质比鲜叶明显增加。所以红茶具有红茶、红汤、红叶和香甜味醇的特征。我国红茶品种以祁门红茶最为著名，为我国第二大茶类。','img/product/detail/_jajcz3m1.png',150123456789,1500,1);
INSERT INTO `mt_tea` VALUES (4,4,"乌龙茶",'250.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶叶包装礼盒包装3两装','乌龙茶也就是青茶，是一类介于红绿茶之间的半发酵茶。乌龙茶在六大类茶中工艺最复杂费时，泡法也最讲究，所以喝乌龙茶也被人称为喝工夫茶。','名贵品种有：武夷岩茶、铁观音、凤凰单丛、台湾乌龙茶。青茶（乌龙茶）----属半发酵茶，即制作时适当发酵，使叶片稍有红变，是介于绿茶与红茶之间的一种茶类。它既有绿茶的鲜浓，又有红茶的甜醇。因其叶片中间为绿色，叶缘呈红色，故有“绿叶红镶边”之称。','img/product/detail/_jajcz3m1.png',15123456789,1500,1);
INSERT INTO `mt_tea` VALUES (5,5,"龙井茶",'150.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',154123456789,888,1);
INSERT INTO `mt_tea` VALUES (6,6,"西湖龙井茶",'199.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,1);
INSERT INTO `mt_tea` VALUES (7,7,"西湖龙井茶",'199.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,0);
INSERT INTO `mt_tea` VALUES (8,1,"碧螺春茶",'250.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);
INSERT INTO `mt_tea` VALUES (9,2,"庐山云雾",'1140.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','散茶包装半两装装。','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',154123456789,1610,1);
INSERT INTO `mt_tea` VALUES (10,3,"阿萨姆红茶",'670.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶饼棉质包装是350g装','红茶，英文为Black tea。红茶在加工过程中发生了以茶多酚酶促氧化为中心的化学反应，鲜叶中的化学成分变化较大，茶多酚减少90%以上，产生了茶黄素红茶属全发酵茶，是以适宜的茶树新牙叶为原料，经萎凋、揉捻（切）、发酵、干燥等一系列工艺过程精制而成的茶。萎凋是红茶初制的重要工艺，红茶在初制时称为“乌茶”。红茶因其干茶冲泡后的茶汤和叶底色呈红色而得名。中国红茶品种主要有：日照红茶、[1]  祁红、昭平红、霍红、滇红、越红、泉城红、泉城绿、苏红、川红、英红、东江楚云仙红茶等，尤以祁门红茶最为著名，2013年湖南东江楚云仙红茶喜获“中茶杯”特等奖。','茶红素等新成分。香气物质比鲜叶明显增加。所以红茶具有红茶、红汤、红叶和香甜味醇的特征。我国红茶品种以祁门红茶最为著名，为我国第二大茶类。','img/product/detail/_jajcz3m1.png',150123456789,1500,1);
INSERT INTO `mt_tea` VALUES (11,4,"乌龙茶",'350.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶叶包装礼盒包装3两装','乌龙茶也就是青茶，是一类介于红绿茶之间的半发酵茶。乌龙茶在六大类茶中工艺最复杂费时，泡法也最讲究，所以喝乌龙茶也被人称为喝工夫茶。','名贵品种有：武夷岩茶、铁观音、凤凰单丛、台湾乌龙茶。青茶（乌龙茶）----属半发酵茶，即制作时适当发酵，使叶片稍有红变，是介于绿茶与红茶之间的一种茶类。它既有绿茶的鲜浓，又有红茶的甜醇。因其叶片中间为绿色，叶缘呈红色，故有“绿叶红镶边”之称。','img/product/detail/_jajcz3m1.png',15123456789,1500,1);
INSERT INTO `mt_tea` VALUES (12,5,"龙井茶",'250.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',154123456789,888,1);
INSERT INTO `mt_tea` VALUES (13,6,"西湖龙井茶",'299.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,1);
INSERT INTO `mt_tea` VALUES (14,7,"西湖龙井茶",'399.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,0);
INSERT INTO `mt_tea` VALUES (15,1,"碧螺春茶",'350.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);
INSERT INTO `mt_tea` VALUES (16,2,"庐山云雾",'1240.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','散茶包装半两装装。','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',154123456789,1610,1);
INSERT INTO `mt_tea` VALUES (17,3,"阿萨姆红茶",'680.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶饼棉质包装是350g装','红茶，英文为Black tea。红茶在加工过程中发生了以茶多酚酶促氧化为中心的化学反应，鲜叶中的化学成分变化较大，茶多酚减少90%以上，产生了茶黄素红茶属全发酵茶，是以适宜的茶树新牙叶为原料，经萎凋、揉捻（切）、发酵、干燥等一系列工艺过程精制而成的茶。萎凋是红茶初制的重要工艺，红茶在初制时称为“乌茶”。红茶因其干茶冲泡后的茶汤和叶底色呈红色而得名。中国红茶品种主要有：日照红茶、[1]  祁红、昭平红、霍红、滇红、越红、泉城红、泉城绿、苏红、川红、英红、东江楚云仙红茶等，尤以祁门红茶最为著名，2013年湖南东江楚云仙红茶喜获“中茶杯”特等奖。','茶红素等新成分。香气物质比鲜叶明显增加。所以红茶具有红茶、红汤、红叶和香甜味醇的特征。我国红茶品种以祁门红茶最为著名，为我国第二大茶类。','img/product/detail/_jajcz3m1.png',150123456789,1500,1);
INSERT INTO `mt_tea` VALUES (18,4,"乌龙茶",'550.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶叶包装礼盒包装3两装','乌龙茶也就是青茶，是一类介于红绿茶之间的半发酵茶。乌龙茶在六大类茶中工艺最复杂费时，泡法也最讲究，所以喝乌龙茶也被人称为喝工夫茶。','名贵品种有：武夷岩茶、铁观音、凤凰单丛、台湾乌龙茶。青茶（乌龙茶）----属半发酵茶，即制作时适当发酵，使叶片稍有红变，是介于绿茶与红茶之间的一种茶类。它既有绿茶的鲜浓，又有红茶的甜醇。因其叶片中间为绿色，叶缘呈红色，故有“绿叶红镶边”之称。','img/product/detail/_jajcz3m1.png',15123456789,1500,1);
INSERT INTO `mt_tea` VALUES (19,5,"龙井茶",'350.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',154123456789,888,1);
INSERT INTO `mt_tea` VALUES (20,6,"西湖龙井茶",'399.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,1);
INSERT INTO `mt_tea` VALUES (21,7,"西湖龙井茶",'599.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,0);
INSERT INTO `mt_tea` VALUES (22,1,"碧螺春茶",'450.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);
INSERT INTO `mt_tea` VALUES (23,2,"庐山云雾",'1340.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','散茶包装半两装装。','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',154123456789,1610,1);
INSERT INTO `mt_tea` VALUES (24,3,"阿萨姆红茶",'690.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶饼棉质包装是350g装','红茶，英文为Black tea。红茶在加工过程中发生了以茶多酚酶促氧化为中心的化学反应，鲜叶中的化学成分变化较大，茶多酚减少90%以上，产生了茶黄素红茶属全发酵茶，是以适宜的茶树新牙叶为原料，经萎凋、揉捻（切）、发酵、干燥等一系列工艺过程精制而成的茶。萎凋是红茶初制的重要工艺，红茶在初制时称为“乌茶”。红茶因其干茶冲泡后的茶汤和叶底色呈红色而得名。中国红茶品种主要有：日照红茶、[1]  祁红、昭平红、霍红、滇红、越红、泉城红、泉城绿、苏红、川红、英红、东江楚云仙红茶等，尤以祁门红茶最为著名，2013年湖南东江楚云仙红茶喜获“中茶杯”特等奖。','茶红素等新成分。香气物质比鲜叶明显增加。所以红茶具有红茶、红汤、红叶和香甜味醇的特征。我国红茶品种以祁门红茶最为著名，为我国第二大茶类。','img/product/detail/_jajcz3m1.png',150123456789,1500,1);
INSERT INTO `mt_tea` VALUES (25,4,"乌龙茶",'650.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶叶包装礼盒包装3两装','乌龙茶也就是青茶，是一类介于红绿茶之间的半发酵茶。乌龙茶在六大类茶中工艺最复杂费时，泡法也最讲究，所以喝乌龙茶也被人称为喝工夫茶。','名贵品种有：武夷岩茶、铁观音、凤凰单丛、台湾乌龙茶。青茶（乌龙茶）----属半发酵茶，即制作时适当发酵，使叶片稍有红变，是介于绿茶与红茶之间的一种茶类。它既有绿茶的鲜浓，又有红茶的甜醇。因其叶片中间为绿色，叶缘呈红色，故有“绿叶红镶边”之称。','img/product/detail/_jajcz3m1.png',15123456789,1500,1);
INSERT INTO `mt_tea` VALUES (26,5,"龙井茶",'550.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',154123456789,888,1);
INSERT INTO `mt_tea` VALUES (27,6,"西湖龙井茶",'599.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,1);
INSERT INTO `mt_tea` VALUES (28,7,"西湖龙井茶",'699.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,0);
INSERT INTO `mt_tea` VALUES (29,1,"碧螺春茶",'550.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);
INSERT INTO `mt_tea` VALUES (30,2,"庐山云雾",'1440.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','散茶包装半两装装。','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',154123456789,1610,1);
INSERT INTO `mt_tea` VALUES (31,3,"阿萨姆红茶",'770.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶饼棉质包装是350g装','红茶，英文为Black tea。红茶在加工过程中发生了以茶多酚酶促氧化为中心的化学反应，鲜叶中的化学成分变化较大，茶多酚减少90%以上，产生了茶黄素红茶属全发酵茶，是以适宜的茶树新牙叶为原料，经萎凋、揉捻（切）、发酵、干燥等一系列工艺过程精制而成的茶。萎凋是红茶初制的重要工艺，红茶在初制时称为“乌茶”。红茶因其干茶冲泡后的茶汤和叶底色呈红色而得名。中国红茶品种主要有：日照红茶、[1]  祁红、昭平红、霍红、滇红、越红、泉城红、泉城绿、苏红、川红、英红、东江楚云仙红茶等，尤以祁门红茶最为著名，2013年湖南东江楚云仙红茶喜获“中茶杯”特等奖。','茶红素等新成分。香气物质比鲜叶明显增加。所以红茶具有红茶、红汤、红叶和香甜味醇的特征。我国红茶品种以祁门红茶最为著名，为我国第二大茶类。','img/product/detail/_jajcz3m1.png',150123456789,1500,1);
INSERT INTO `mt_tea` VALUES (32,4,"乌龙茶",'750.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','茶叶包装礼盒包装3两装','乌龙茶也就是青茶，是一类介于红绿茶之间的半发酵茶。乌龙茶在六大类茶中工艺最复杂费时，泡法也最讲究，所以喝乌龙茶也被人称为喝工夫茶。','名贵品种有：武夷岩茶、铁观音、凤凰单丛、台湾乌龙茶。青茶（乌龙茶）----属半发酵茶，即制作时适当发酵，使叶片稍有红变，是介于绿茶与红茶之间的一种茶类。它既有绿茶的鲜浓，又有红茶的甜醇。因其叶片中间为绿色，叶缘呈红色，故有“绿叶红镶边”之称。','img/product/detail/_jajcz3m1.png',15123456789,1500,1);
INSERT INTO `mt_tea` VALUES (33,5,"龙井茶",'650.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',154123456789,888,1);
INSERT INTO `mt_tea` VALUES (34,6,"西湖龙井茶",'699.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,1);
INSERT INTO `mt_tea` VALUES (35,7,"西湖龙井茶",'799.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,0);
INSERT INTO `mt_tea` VALUES (36,1,"碧螺春茶",'650.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);
INSERT INTO `mt_tea` VALUES (37,6,"西湖龙井茶",'799.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,1);
INSERT INTO `mt_tea` VALUES (38,7,"西湖龙井茶",'899.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1斤装','西湖龙井位列中国十大名茶之首，清乾隆游览杭州西湖时，盛赞龙井茶，并把狮峰山下胡公庙前的十八棵茶树封为“御茶”。得名于龙井。龙井位于西湖之西翁家山的西北麓，也就是现在的龙井村。龙井原名龙泓，是一个圆形的泉池，大旱不涸，古人以为此泉与海相通，其中有龙，因称龙井，传说晋代葛洪曾在此炼丹。','龙井茶[1]  是中国传统名茶，著名绿茶之一。产于浙江杭州西湖龙井村一带，已有一千二百余年历史。龙井茶色泽翠绿，香气浓郁，甘醇爽口，形如雀舌，即有“色绿、香郁、味甘、形美”四绝的特点。龙井茶得名于龙井。龙井位于西湖之西翁家山的西北麓的龙井茶村。龙井茶因其产地不同，分为西湖龙井、钱塘龙井（萧山、富阳）、越州龙井（绍兴地区：包括新昌县（大佛龙井）、嵊州市（越乡龙井））三种，除了杭州市西湖区所管辖的范围（龙井村梅家坞至龙坞转塘 十三个生产大队）的茶叶叫作西湖龙井外，其它产地产的俗称为浙江龙井茶。浙江龙井又以越州龙井为胜。','img/product/detail/_jajcrc6c.jpg',155123456789,2511,0);
INSERT INTO `mt_tea` VALUES (39,1,"碧螺春茶",'750.00','*退货补运费 *30天无忧退货 *48小时快速退款 *72小时发货','礼盒包装1两装','绿茶：茶是不经过发酵的茶，即将鲜叶经过摊晾后直接下到一二百度的热锅里炒制，以保持其绿色的特点。','绿茶----这是我国产量最多的一类茶叶，其花色品种之多居世界首位。绿茶具有香高、味醇、形美、耐冲泡等特点。其制作工艺都经过杀青一揉捻一干燥的过程。由于加工时干燥的方法不同，绿茶又可分为炒青绿茶、烘青绿茶、蒸青绿茶和晒清绿茶。绿茶是我国产量最多的一类茶叶，全国18个产茶省（区）都生产绿茶。我国绿茶花色品种之多居世界之首，每年出口数万吨，占世界茶叶市场绿茶贸易量的70％左右。我国传统绿茶--眉茶和珠茶，向以香高、味醇、形美、耐冲泡，而深受国内外消费者的欢迎。','img/product/detail/_jajcq800.png',155123456789,1200,1);




-- Table structure for `mt_tea_family`
DROP TABLE IF EXISTS `mt_tea_family`;
CREATE TABLE `mt_tea_family` (
  `fid` int(11) PRIMARY KEY NOT NULL auto_increment,
  `fname` varchar(32) default NULL
);

-- Records of mt_tea_family
INSERT INTO `mt_tea_family` VALUES ('1', '碧螺春茶');
INSERT INTO `mt_tea_family` VALUES ('2', '庐山云雾');
INSERT INTO `mt_tea_family` VALUES ('4', '乌龙茶');
INSERT INTO `mt_tea_family` VALUES ('5', '龙井茶');
INSERT INTO `mt_tea_family` VALUES ('6', '西湖龙井茶');






-- mt_tea_pic
DROP TABLE IF EXISTS `mt_tea_pic`;
CREATE TABLE   `mt_tea_pic` (
    `pid` INT(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `tea_id` INT(11) DEFAULT NULL,  -- lid
    `sm` VARCHAR(128) DEFAULT NULL,
    `md` VARCHAR(128) DEFAULT NULL,
    `lg` VARCHAR(128) DEFAULT NULL
);

INSERT INTO `mt_tea_pic` VALUES(1,1,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(2,2,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(3,3,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(4,4,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(5,5,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(6,6,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(7,1,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(8,1,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(9,1,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(10,1,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(11,1,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(12,1,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(13,1,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(14,2,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(15,2,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(16,2,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(17,2,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(18,3,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(19,3,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(20,3,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(21,3,'img/product/sm/1532351239.png','img/product/md/1532351239.png','img/product/lg/1532351239.png');
INSERT INTO `mt_tea_pic` VALUES(22,3,'img/product/sm/1523608474780080.png','img/product/md/1523608474780080.png','img/product/lg/1523608474780080.png');
INSERT INTO `mt_tea_pic` VALUES(23,4,'img/product/sm/1523612436140989.png','img/product/md/1523612436140989.png','img/product/lg/1523612436140989.png');
INSERT INTO `mt_tea_pic` VALUES(24,4,'img/product/sm/1523612554494090.png','img/product/md/1523612554494090.png','img/product/lg/1523612554494090.png');
INSERT INTO `mt_tea_pic` VALUES(25,4,'img/product/sm/1523848116100272.png','img/product/md/1523848116100272.png','img/product/lg/1523848116100272.png');
INSERT INTO `mt_tea_pic` VALUES(26,5,'img/product/sm/1523848314876127.png','img/product/md/1523848314876127.png','img/product/lg/1523848314876127.png');
INSERT INTO `mt_tea_pic` VALUES(27,5,'img/product/sm/1523850054107458.png','img/product/md/1523850054107458.png','img/product/lg/1523850054107458.png');
INSERT INTO `mt_tea_pic` VALUES(28,5,'img/product/sm/1523587252.png','img/product/md/1523587252.png','img/product/lg/1523587252.png');
INSERT INTO `mt_tea_pic` VALUES(29,6,'img/product/sm/1523848694521889.png','img/product/md/1523848694521889.png','img/product/lg/1523848694521889.png');
INSERT INTO `mt_tea_pic` VALUES(30,6,'img/product/sm/1523850054107458.png','img/product/md/1523850054107458.png','img/product/lg/1523850054107458.png');
INSERT INTO `mt_tea_pic` VALUES(31,6,'img/product/sm/1523585672.png','img/product/md/1523585672.png','img/product/lg/1523585672.png');
INSERT INTO `mt_tea_pic` VALUES(32,6,'img/product/sm/1523587252.png','img/product/md/1523587252.png','img/product/lg/1523587252.png');
INSERT INTO `mt_tea_pic` VALUES(33,6,'img/product/sm/1523587294.png','img/product/md/1523587294.png','img/product/lg/1523587294.png');
INSERT INTO `mt_tea_pic` VALUES(34,6,'img/product/sm/1523588299.png','img/product/md/1523588299.png','img/product/lg/1523588299.png');
INSERT INTO `mt_tea_pic` VALUES(35,6,'img/product/sm/1523602543.png','img/product/md/1523602543.png','img/product/lg/1523602543.png');
INSERT INTO `mt_tea_pic` VALUES(36,6,'img/product/sm/1523604669.png','img/product/md/1523604669.png','img/product/lg/1523604669.png');
INSERT INTO `mt_tea_pic` VALUES(37,7,'img/product/sm/1523850054107458.png','img/product/md/1523850054107458.png','img/product/lg/1523850054107458.png');
INSERT INTO `mt_tea_pic` VALUES(38,7,'img/product/sm/1523587252.png','img/product/md/1523587252.png','img/product/lg/1523587252.png');
INSERT INTO `mt_tea_pic` VALUES(39,7,'img/product/sm/1523848694521889.png','img/product/md/1523848694521889.png','img/product/lg/1523848694521889.png');
INSERT INTO `mt_tea_pic` VALUES(40,8,'img/product/sm/1523850054107458.png','img/product/md/1523850054107458.png','img/product/lg/1523850054107458.png');
INSERT INTO `mt_tea_pic` VALUES(41,8,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(42,8,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(43,8,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(44,8,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(45,8,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(46,8,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(47,9,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(48,9,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(49,9,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(50,10,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(51,10,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(52,10,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(53,10,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(54,10,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(55,10,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(56,10,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(57,10,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(58,10,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(59,11,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(60,11,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(61,11,'img/product/sm/1532351239.png','img/product/md/1532351239.png','img/product/lg/1532351239.png');
INSERT INTO `mt_tea_pic` VALUES(62,11,'img/product/sm/1523608474780080.png','img/product/md/1523608474780080.png','img/product/lg/1523608474780080.png');
INSERT INTO `mt_tea_pic` VALUES(63,11,'img/product/sm/1523612436140989.png','img/product/md/1523612436140989.png','img/product/lg/1523612436140989.png');
INSERT INTO `mt_tea_pic` VALUES(64,11,'img/product/sm/1523612554494090.png','img/product/md/1523612554494090.png','img/product/lg/1523612554494090.png');
INSERT INTO `mt_tea_pic` VALUES(65,12,'img/product/sm/1523848116100272.png','img/product/md/1523848116100272.png','img/product/lg/1523848116100272.png');
INSERT INTO `mt_tea_pic` VALUES(66,12,'img/product/sm/1523848314876127.png','img/product/md/1523848314876127.png','img/product/lg/1523848314876127.png');
INSERT INTO `mt_tea_pic` VALUES(67,12,'img/product/sm/1523850054107458.png','img/product/md/1523850054107458.png','img/product/lg/1523850054107458.png');
INSERT INTO `mt_tea_pic` VALUES(68,12,'img/product/sm/1523587252.png','img/product/md/1523587252.png','img/product/lg/1523587252.png');
INSERT INTO `mt_tea_pic` VALUES(69,13,'img/product/sm/1523848694521889.png','img/product/md/1523848694521889.png','img/product/lg/1523848694521889.png');
INSERT INTO `mt_tea_pic` VALUES(70,13,'img/product/sm/1523850054107458.png','img/product/md/1523850054107458.png','img/product/lg/1523850054107458.png');
INSERT INTO `mt_tea_pic` VALUES(71,14,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(72,14,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(73,14,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(74,14,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(75,14,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(76,14,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(77,15,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(78,15,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(79,15,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(80,16,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(81,16,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(82,16,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(83,16,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(84,16,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(85,16,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(86,16,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(87,17,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(88,17,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(89,17,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(90,17,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(91,21,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(92,21,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(93,21,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(94,22,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(95,22,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(96,22,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(97,22,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(98,22,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(99,22,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(100,23,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(101,23,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(102,23,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(103,23,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(104,23,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(105,23,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(106,23,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(107,23,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(108,23,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(109,23,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(110,24,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(111,24,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(112,24,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(113,24,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(114,24,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(115,24,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(116,24,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(117,25,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(118,25,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(119,25,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(120,26,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(121,26,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(122,26,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(123,26,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(124,26,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(125,26,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(126,26,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(127,27,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(128,27,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(129,27,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(130,27,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(131,28,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(132,28,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(133,28,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(134,28,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(135,28,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(136,28,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(137,29,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(138,29,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(139,29,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(140,30,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(141,30,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(142,30,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(143,30,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(144,30,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(145,30,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(146,30,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(147,30,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(148,30,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(149,31,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(150,31,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(151,31,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(152,31,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(153,31,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(154,32,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(155,32,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(156,32,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(157,32,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(158,32,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(159,32,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(160,32,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(161,33,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(162,33,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(163,33,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(164,33,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(165,33,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(166,33,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(167,34,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(168,34,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(169,34,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(170,34,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(171,34,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(172,34,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(173,35,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(174,35,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(175,35,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(176,35,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(177,35,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(178,35,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(179,35,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(180,35,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(181,36,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(182,36,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(183,36,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(184,36,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(185,36,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(186,36,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(187,36,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(188,36,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(189,36,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(190,37,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(191,37,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(192,37,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(193,37,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(194,37,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(195,37,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(196,37,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(197,37,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(198,37,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(199,38,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(201,38,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(202,38,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(203,38,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(204,38,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(205,39,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(206,39,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(207,39,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(208,39,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(209,39,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(210,39,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(211,19,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(212,19,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(213,19,'img/product/sm/1531813185.png','img/product/md/1531813185.png','img/product/lg/1531813185.png');
INSERT INTO `mt_tea_pic` VALUES(214,19,'img/product/sm/1532070389.png','img/product/md/1532070389.png','img/product/lg/1532070389.png');
INSERT INTO `mt_tea_pic` VALUES(215,19,'img/product/sm/1532077463.png','img/product/md/1532077463.png','img/product/lg/1532077463.png');
INSERT INTO `mt_tea_pic` VALUES(216,19,'img/product/sm/1532349984.png','img/product/md/1532349984.png','img/product/lg/1532349984.png');
INSERT INTO `mt_tea_pic` VALUES(217,19,'img/product/sm/1532350026.png','img/product/md/1532350026.png','img/product/lg/1532350026.png');
INSERT INTO `mt_tea_pic` VALUES(218,20,'img/product/sm/1532350182.png','img/product/md/1532350182.png','img/product/lg/1532350182.png');
INSERT INTO `mt_tea_pic` VALUES(219,20,'img/product/sm/1532350420.png','img/product/md/1532350420.png','img/product/lg/1532350420.png');
INSERT INTO `mt_tea_pic` VALUES(220,20,'img/product/sm/1532350464.png','img/product/md/1532350464.png','img/product/lg/1532350464.png');
INSERT INTO `mt_tea_pic` VALUES(221,20,'img/product/sm/1532350563.png','img/product/md/1532350563.png','img/product/lg/1532350563.png');
INSERT INTO `mt_tea_pic` VALUES(222,20,'img/product/sm/1532350840.png','img/product/md/1532350840.png','img/product/lg/1532350840.png');
INSERT INTO `mt_tea_pic` VALUES(223,20,'img/product/sm/1532350848.png','img/product/md/1532350848.png','img/product/lg/1532350848.png');
INSERT INTO `mt_tea_pic` VALUES(224,20,'img/product/sm/1.png','img/product/md/1.png','img/product/lg/1.png');
INSERT INTO `mt_tea_pic` VALUES(225,20,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(226,20,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(227,20,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(228,20,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(229,20,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(230,20,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(231,20,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(232,20,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(233,18,'img/product/sm/2.png','img/product/md/2.png','img/product/lg/2.png');
INSERT INTO `mt_tea_pic` VALUES(234,18,'img/product/sm/3.png','img/product/md/3.png','img/product/lg/3.png');
INSERT INTO `mt_tea_pic` VALUES(235,18,'img/product/sm/4.png','img/product/md/4.png','img/product/lg/4.png');
INSERT INTO `mt_tea_pic` VALUES(236,18,'img/product/sm/5.png','img/product/md/5.png','img/product/lg/5.png');
INSERT INTO `mt_tea_pic` VALUES(237,18,'img/product/sm/6.png','img/product/md/6.png','img/product/lg/6.png');
INSERT INTO `mt_tea_pic` VALUES(238,18,'img/product/sm/1523605901.png','img/product/md/1523605901.png','img/product/lg/1523605901.png');
INSERT INTO `mt_tea_pic` VALUES(239,18,'img/product/sm/1523861659.png','img/product/md/1523861659.png','img/product/lg/1523861659.png');
INSERT INTO `mt_tea_pic` VALUES(240,18,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');
INSERT INTO `mt_tea_pic` VALUES(241,13,'img/product/sm/1531810993.png','img/product/md/1531810993.png','img/product/lg/1531810993.png');






#mt_shoppingcart_item
DROP TABLE IF EXISTS `mt_shoppingcart_item`;
CREATE TABLE `mt_shoppingcart_item`(
    `iid` int(11) NOT NULL auto_increment,
    `user_id` int(11) default NULL,
    `product_id` int(11) default NULL,
    `count` int(11) default NULL,
    `is_checked` tinyint(1) default NULL,
    PRIMARY KEY (`iid`)
);
INSERT INTO `mt_shoppingcart_item` VALUES(1,10,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(2,11,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(3,12,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(4,13,3,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(5,14,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(13,20,1,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(14,22,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(15,20,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(16,25,11,77654,1);
INSERT INTO `mt_shoppingcart_item` VALUES(17,3,12,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(18,3,18,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(19,32,1,14,0);
INSERT INTO `mt_shoppingcart_item` VALUES(20,10,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(21,11,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(22,12,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(23,13,3,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(24,14,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(25,20,1,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(26,22,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(27,20,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(28,25,11,77654,1);
INSERT INTO `mt_shoppingcart_item` VALUES(29,3,12,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(30,3,18,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(31,32,1,14,0);
INSERT INTO `mt_shoppingcart_item` VALUES(32,10,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(33,11,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(34,12,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(35,13,3,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(36,14,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(37,20,1,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(38,22,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(39,20,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(40,25,11,77654,1);
INSERT INTO `mt_shoppingcart_item` VALUES(41,3,12,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(42,3,18,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(43,32,1,14,0);
INSERT INTO `mt_shoppingcart_item` VALUES(44,10,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(45,11,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(46,12,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(47,13,3,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(48,14,1,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(49,20,1,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(50,22,17,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(51,20,11,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(52,25,11,77654,1);
INSERT INTO `mt_shoppingcart_item` VALUES(53,3,12,1,0);
INSERT INTO `mt_shoppingcart_item` VALUES(54,3,18,1,1);
INSERT INTO `mt_shoppingcart_item` VALUES(55,32,1,14,0);

#mt_user
DROP TABLE IF EXISTS `mt_user`;
CREATE TABLE `mt_user` (
    `uid` int(11) NOT NULL auto_increment,
    `uname` varchar(32) default NULL,
    `upwd` varchar(64) default NULL,
    `email` varchar(64) default NULL,
    `phone` varchar(16) default NULL,
    `avatar` varchar(128) default NULL,
    `user_name` varchar(32) default NULL,
    `gender` int(11) default NULL,
    PRIMARY KEY (`uid`)
);
INSERT INTO `mt_user` VALUES(1,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(2,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(3,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(4,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(5,'丫丫','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(6,'豆豆','123456','333@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(7,'1114','111113','444@qq.com','15962220011','null','null',null);
INSERT INTO `mt_user` VALUES(8,'花花','111114','555@qq.com','15962220012','null','null',null);
INSERT INTO `mt_user` VALUES(9,'1116','123456','666@qq.com','15962220013','null','null',null);
INSERT INTO `mt_user` VALUES(10,'狗狗','123456','78@qq.com','15962220018','null','null',null);
INSERT INTO `mt_user` VALUES(11,'1118','123456','888@qq.com','15962220015','null','null',null);
INSERT INTO `mt_user` VALUES(12,'1119','111111','2198@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(13,'1110','123456','13298@qq.com','15962221006','null','null',null);
INSERT INTO `mt_user` VALUES(14,'1111','123456','238@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(15,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(16,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(17,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(18,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(19,'1112','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(20,'1113','123456','333@qq.com','15962255005','null','红红',null);
INSERT INTO `mt_user` VALUES(21,'1114','111113','4dd4@qq.com','15962220011','null','阿里晕晕',null);
INSERT INTO `mt_user` VALUES(22,'1115','111114','eee5@qq.com','15962260012','null','绿绿',null);
INSERT INTO `mt_user` VALUES(23,'1116','123456','6rs@qq.com','15962227013','null','null',null);
INSERT INTO `mt_user` VALUES(24,'1117','123456','7e@qq.com','15962220818','null','null',null);
INSERT INTO `mt_user` VALUES(25,'1118','123456','teee@qq.com','15962220015','null','拉拉',null);
INSERT INTO `mt_user` VALUES(26,'1119','111111','2er8@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(27,'1110','123456','1ty98@qq.com','15962221006','null','兰兰',null);
INSERT INTO `mt_user` VALUES(28,'1111','123456','ity8@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(29,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(30,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(31,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(32,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(33,'1112','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(34,'1113','123456','333@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(35,'1114','111113','444@qq.com','15962220011','null','null',null);
INSERT INTO `mt_user` VALUES(36,'1115','111114','555@qq.com','15962220012','null','null',null);
INSERT INTO `mt_user` VALUES(37,'1116','123456','666@qq.com','15962220013','null','null',null);
INSERT INTO `mt_user` VALUES(38,'1117','123456','78@qq.com','15962220018','null','null',null);
INSERT INTO `mt_user` VALUES(39,'1118','123456','888@qq.com','15962220015','null','null',null);
INSERT INTO `mt_user` VALUES(40,'1119','111111','2198@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(41,'1110','123456','13298@qq.com','15962221006','null','null',null);
INSERT INTO `mt_user` VALUES(42,'1111','123456','238@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(43,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(44,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(45,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(46,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(47,'1112','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(48,'1113','123456','333@qq.com','15962255005','null','红红',null);
INSERT INTO `mt_user` VALUES(49,'1114','111113','4dd4@qq.com','15962220011','null','阿里晕晕',null);
INSERT INTO `mt_user` VALUES(50,'1115','111114','eee5@qq.com','15962260012','null','绿绿',null);
INSERT INTO `mt_user` VALUES(51,'1116','123456','6rs@qq.com','15962227013','null','null',null);
INSERT INTO `mt_user` VALUES(52,'1117','123456','7e@qq.com','15962220818','null','null',null);
INSERT INTO `mt_user` VALUES(53,'1118','123456','teee@qq.com','15962220015','null','拉拉',null);
INSERT INTO `mt_user` VALUES(54,'1119','111111','2er8@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(55,'1110','123456','1ty98@qq.com','15962221006','null','兰兰',null);
INSERT INTO `mt_user` VALUES(56,'1111','123456','ity8@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(57,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(58,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(59,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(60,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(61,'1112','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(62,'1113','123456','333@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(63,'1114','111113','444@qq.com','15962220011','null','null',null);
INSERT INTO `mt_user` VALUES(64,'1115','111114','555@qq.com','15962220012','null','null',null);
INSERT INTO `mt_user` VALUES(65,'1116','123456','666@qq.com','15962220013','null','null',null);
INSERT INTO `mt_user` VALUES(66,'1117','123456','78@qq.com','15962220018','null','null',null);
INSERT INTO `mt_user` VALUES(67,'1118','123456','888@qq.com','15962220015','null','null',null);
INSERT INTO `mt_user` VALUES(68,'1119','111111','2198@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(69,'1110','123456','13298@qq.com','15962221006','null','null',null);
INSERT INTO `mt_user` VALUES(70,'1111','123456','238@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(71,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(72,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(73,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(74,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(75,'1112','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(76,'1113','123456','333@qq.com','15962255005','null','红红',null);
INSERT INTO `mt_user` VALUES(77,'1114','111113','4dd4@qq.com','15962220011','null','阿里晕晕',null);
INSERT INTO `mt_user` VALUES(78,'1115','111114','eee5@qq.com','15962260012','null','绿绿',null);
INSERT INTO `mt_user` VALUES(79,'1116','123456','6rs@qq.com','15962227013','null','null',null);
INSERT INTO `mt_user` VALUES(80,'1117','123456','7e@qq.com','15962220818','null','null',null);
INSERT INTO `mt_user` VALUES(81,'1118','123456','teee@qq.com','15962220015','null','拉拉',null);
INSERT INTO `mt_user` VALUES(82,'1119','111111','2er8@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(83,'1110','123456','1ty98@qq.com','15962221006','null','兰兰',null);
INSERT INTO `mt_user` VALUES(84,'1111','123456','ity8@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(85,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(86,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(87,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);
INSERT INTO `mt_user` VALUES(88,'momo','123456','mo@qq.com','15962220003','img/avatar/default.png','沫沫',1);
INSERT INTO `mt_user` VALUES(89,'1112','123321','222@qq.com','15962220004','null','null',null);
INSERT INTO `mt_user` VALUES(90,'1113','123456','333@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(91,'1114','111113','444@qq.com','15962220011','null','null',null);
INSERT INTO `mt_user` VALUES(92,'1115','111114','555@qq.com','15962220012','null','null',null);
INSERT INTO `mt_user` VALUES(93,'1116','123456','666@qq.com','15962220013','null','null',null);
INSERT INTO `mt_user` VALUES(94,'1117','123456','78@qq.com','15962220018','null','null',null);
INSERT INTO `mt_user` VALUES(95,'1118','123456','888@qq.com','15962220015','null','null',null);
INSERT INTO `mt_user` VALUES(96,'1119','111111','2198@qq.com','15962220117','null','null',null);
INSERT INTO `mt_user` VALUES(97,'1110','123456','13298@qq.com','15962221006','null','null',null);
INSERT INTO `mt_user` VALUES(98,'1111','123456','238@qq.com','15962220005','null','null',null);
INSERT INTO `mt_user` VALUES(99,'dingding','123456','ding@qq.com','15962220000','img/avatar/default.png','丁春秋',0);
INSERT INTO `mt_user` VALUES(100,'dangdang','123456','dang@qq.com','15962220001','img/avatar/default.png','当当猫',0);
INSERT INTO `mt_user` VALUES(101,'doudou','123456','dou@qq.com','15962220002','img/avatar/default.png','豆豆',1);



